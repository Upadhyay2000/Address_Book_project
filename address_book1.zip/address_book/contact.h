#ifndef CONTACT_H
#define CONTACT_H

#define MAX_CONTACTS 100

typedef struct {
    char name[50];
    char phone[20];
    char email[50];
} Contact;

typedef struct {
    Contact contacts[MAX_CONTACTS];
    int contactCount;
} AddressBook;

void createContact(AddressBook *addressBook);
void searchContact(AddressBook *addressBook);
void editContact(AddressBook *addressBook);
void deleteContact(AddressBook *addressBook);
void listContacts(AddressBook *addressBook, int sortCriteria);
void initialize(AddressBook *addressBook);
void saveContactsToFile(AddressBook *AddressBook);
int validate_email(char *email,AddressBook *addressBook);
int validate_name(char *name);
int validate_number(char *num,AddressBook *addressBook);
int search_name(char *name);
int search_phone(AddressBook *addressBook,char phone1[]);
int search_email(AddressBook *addressbook,char email[]);
int validate_number_search(char *phone);
void loadContactsFromFile(AddressBook *addressBook);

#endif
