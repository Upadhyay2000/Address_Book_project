#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
#include "populate.h"
int k;

void listContacts(AddressBook *addressBook, int sortCriteria) // for listing the contacts
{
    // Sort contacts based on the chosen criteria
    Contact temp;
    //printf("size = %d , sort = %d\n", addressBook->contactCount, sortCriteria);
    printf("\nName\tphone no\temail id\n\n");
    if(sortCriteria==1)
    {
        for(int i=0;i<addressBook->contactCount-1;i++)  //
        {
            //printf("%d\n", i);
            for(int j=0;j<addressBook->contactCount-i-1;j++)
            {
                if(strcmp(addressBook->contacts[j].name,addressBook->contacts[j+1].name)>0)
                {
                    temp = addressBook->contacts[j];
                    addressBook->contacts[j] = addressBook->contacts[j+1];
                    addressBook->contacts[j+1] = temp;
                }
            }
        }
    }
    else if(sortCriteria==2)
    {
        for(int i=0;i<addressBook->contactCount-1;i++)
        {
            for(int j=0;j<addressBook->contactCount-i-1;j++)
            {
                if(strcmp(addressBook->contacts[j].phone,addressBook->contacts[j+1].phone)>0)
                {
                    temp = addressBook->contacts[j];
                    addressBook->contacts[j] = addressBook->contacts[j+1];
                    addressBook->contacts[j+1] = temp;
                }
            }
        }   
    }
    else{
         for(int i=0;i<addressBook->contactCount-1;i++)
        {
            for(int j=0;j<addressBook->contactCount-i-1;j++)
            {
                if(strcmp(addressBook->contacts[j].email,addressBook->contacts[j+1].email)>0)
                {
                    temp = addressBook->contacts[j];
                    addressBook->contacts[j] = addressBook->contacts[j+1];
                    addressBook->contacts[j+1] = temp;
                }
            }
        }
    }
    for(int i=0;i<addressBook->contactCount;i++)
     printf("%s\t%s\t%s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
}

/*void initialize(AddressBook *addressBook) { 
    // Load contacts from file during initialization (After files)
    //loadContactsFromFile(addressBook);
    addressBook->contactCount = 0;
    populateAddressBook(addressBook);
    loadContactsFromFile(addressBook);
}*/

void saveAndExit(AddressBook *addressBook) {
    // Save contacts to file
    // Exit the program
    saveContactsToFile(addressBook);
    exit(EXIT_SUCCESS);
    
}

void createContact(AddressBook *addressBook)
{
	/* Define the logic to create a Contacts */
    char name[50],num[50],email[50];
    int i,res;
    
    do{
        
         printf("Enter your name: ");
         scanf(" %[^\n]",name);
         res = validate_name(name);                        // calling a fuction to check name is valid or not                                    
    } while (res == 1);
    strcpy(addressBook->contacts[addressBook->contactCount].name,name);         // if name is valid then store that name
    
    do
    {
        printf("Enter phone number: ");
        scanf("%s",num);
       res= validate_number(num,addressBook);                             // calling a fuction to check phone number is valid or not  
        
    } while (res ==1);
    strcpy(addressBook->contacts[addressBook->contactCount].phone,num);      // if phone numner is valid then store that number
    
    do
    {
        printf("Enter Email address: ");
        scanf(" %[^\n]",email);
        res = validate_email(email,addressBook);                          // calling a function to check Email is valid or not
        
    } while (res == 1);
    strcpy(addressBook->contacts[addressBook->contactCount].email,email);   // if Email is valid then store that Email
    addressBook -> contactCount++;                                         // increase the contactcount value
    printf("\n.............................Contact Created Successfully...............................\n");
}
int validate_name(char *name)
{
    int i;
    for(i=0;name[i];i++)
        {
            if(name[i]>='A' && name[i]<='Z' || name[i]>='a' && name[i]<='z' || name[i]==' ')
            {
              
            }
            else
            {
                printf("Invalid name");
                return 1;
            }
           
        } 
        return 0; 
}
int validate_number(char *num,AddressBook *addressBook)
{
    int i,l;
    l= strlen(num);            // checking for phone number , it should be of 10 digits
    if(l==10)
    {
        for(i=0;i<addressBook->contactCount;i++)   // checking for unique number
        {
            if(strcmp(num,addressBook->contacts[i].phone)==0)
            {
                printf("phone number already there");
                return 1;
            }

        }
          for(i=0;num[i];i++)
        {
            if(num[i]>='0' && num[i]<='9')
            {
        
            }
            else
            {
                printf("Invalid number\n");
                printf("Enter valid number\n");
                return 1;
            }
        }
        return 0;
    }
    else
    {
        printf("Invalid number\n");
        printf("Enter valid number\n");

        return 1;
    } 
}

int validate_email(char *email,AddressBook *addressBook)
{
        int i;

        if(email[0] == '@' || (email[0] <= '9' && email[0] >= '0') || email[0] == '.') //checking for the first charecter 
        {
            printf("INvalid email\n");
            return 1;
        }

        char *ptr = strstr(email, ".com");            // checking .com is present or not in email
        if(ptr==NULL)
        {
             printf("Invalid Email\n"); // .com is not present return 1;
             return 1;
        }

        if(*(ptr+4)!='\0') // For checking the .com is present in the last or not
        return 1;
        
          //check @ is present or not
        char *ptr1 = strchr(email,'@');
        if(ptr1==NULL)        //checking for @
        {
            printf("Invalid Email\n");
            return 1;
        }
        for(i=0;i<addressBook->contactCount;i++)    // checking for unique email
        {
            if(strcmp(email,addressBook->contacts[i].email)==0)
            {
                printf("Enmail id already there");
                return 1;
            }
            
        }
         
        for(i=0;email[i];i++)
        {
            
                if (email[i]>='a' && email[i]<='z' || email[i]>= '0' && email[i]<='9' || email[i]=='@' || email[i]=='.')
                {
                
                }
                else
                {
                    printf("Invalid email by characters\n");
                    return 1;
                }
        }
         return 0;
}
      // ..............................Contact Added Successfully..............................................................//    
void searchContact(AddressBook *addressBook) 
{
    int option,res1,res2,count=0;
    char name[50],phone1[50],email[50];
    printf("\n1.Enter Name\n2.Enter phone number\n3.Enter Email address\n");
    printf("Enter the option: ");
    scanf("%d",&option);
    if(option>3)
    {
        printf("Enter valid option\n");
        return;
    }
    switch (option)
    {
    case 1:
       printf("Enter name: ");
       scanf(" %[^\n]",name);
        res1 = search_name(name);
        if(res1==0)
        {
            int j,count=0;
            for(j=0;j<addressBook->contactCount;j++)
            {
                if(strstr(addressBook->contacts[j].name,name)!=NULL)   //checking name present or not
                { 
                    printf("\n%s\t\t%s\t\t%s\n",addressBook->contacts[j].name,addressBook->contacts[j].phone,addressBook->contacts[j].email);
                    k = j;
                    count++;  // Display all details
                }  
            }
            if(count>1)
            {
                char str[12];
                printf("Enter the number to select a contact : ");
                scanf("%s", str);

                res1 = validate_number_search(str);
                if(res1 == 1)
                {
                    printf("Invalid number\n");
                    return;
                }
                k=search_phone(addressBook,str);
                if(k==-1)
                {
                    printf("Contact not found");
                    searchContact(addressBook);
                }  
                else
                {
                    // if found display the contact details
                    printf("\n%s\t\t%s\t\t%s\n",addressBook->contacts[k].name,addressBook->contacts[k].email,addressBook->contacts[k].phone);
                }
            }
        }
        else
        {
             printf("Not valid\nEnter proper name");
             return;
        }  
        break;
        case 2:
            printf("Enter phone number: ");
        scanf(" %[^\n]",phone1);
        res1 = validate_number_search(phone1);
        if(res1 == 1)
        {
            printf("Invalid number\n");
            return;
        }
          k=search_phone(addressBook,phone1);
          if(k==-1)
          {
            printf("Contact not found");
            searchContact(addressBook);
          }  
          else
          {
            // if found display the contact details
               printf("\n%s\t\t%s\t\t%s\n",addressBook->contacts[k].name,addressBook->contacts[k].email,addressBook->contacts[k].phone);
          }
       
        break;
        case 3:
        printf("Enter Email address: ");
        scanf(" %[^\n]",email);
        k=search_email(addressBook,email);
        if(k==-1)
        {
            printf("Contact not found");
            searchContact(addressBook);
        }
        else
        {
               printf("\n%s\t\t%s\t\t%s",addressBook->contacts[k].name,addressBook->contacts[k].email,addressBook->contacts[k].phone);
        }
        break;
       default:
       printf("Invalid input\n");
        break;
    }
    //printf("....................................Search Contact Successfully Completed.............................................\n");
}
int search_name(char *name)
{
    int i;
    for(i=0;name[i];i++)
        {
            if(name[i]>='A' && name[i]<='Z' || name[i]>='a' && name[i]<='z' || name[i]==' ')
            {
              
            }
            else
                return 1;
        } 
        return 0; 
}
int validate_number_search(char *phone)
{
    int i,l;
    l=strlen(phone);
    if(l==10)
    {
        for(i=0;phone[i];i++)
        {
            if(phone[i]>='0'&&phone[i]<='9')
            {

            }
            else
            {
                return 1;
                break;
            }
        }
        return 0;
    }
    else
    return 1;
}
int search_phone(AddressBook *addressBook,char *phone)
{
    int l;
    for(l=0;l<addressBook->contactCount;l++)
    {
         if(strcmp(addressBook->contacts[l].phone,phone)==0)        // compare the phone number of each elements with the input phone number
         {
            return l;
         }
    }
    return -1;
}
int search_email(AddressBook *addressbook,char *email)
{
    int m;
    for(m=0;m<addressbook->contactCount;m++)
    {
         if(strcmp(addressbook->contacts[m].email,email)==0)        // compare the phone number of each elements with the input phone number
         {
            return m;
         }
    }
    return -1;
}
//....................................................Search Contact Sucessfully Completed.........................................................................//
void editContact(AddressBook *addressBook)  // Function to edit the contact details
{
	/* Define the logic for Editcontact */
    
    printf("Search the contact based on following option \n");
    printf("Enter 1 to search by name\n");
    printf("Enter 2 to search by phone\n");
    printf("Enter 3 to search by email\n");
    int choice,option;
    scanf("%d",&choice); // read the choice

    switch (choice)
    {
    case 1:
           char searchName[40];
           printf("Enter name to search: ");
           scanf(" %[^\n]",searchName);   // read the name to search
           
           int flag =0;
           int j=0;
           for(int i=0;i<addressBook->contactCount;i++)
           {
             if(strcasecmp(addressBook->contacts[i].name,searchName)==0) // if name found increment flag value
             {
                flag++;
                j=i;
             }
           }
           if(flag==1)
           {
             printf("Contact found: Name: %s  phone: %s    Email: %s\n",  // Display the detail and ask what you want to edit
             addressBook->contacts[j].name,
             addressBook->contacts[j].phone,
             addressBook->contacts[j].email);

             printf("What you want to edit :\n");
             printf("Enter 1 to edit name\n");
             printf("Enter 2 to edit phone\n");
             printf("Enter 3 to edit email\n");
             //__fpurge(stdin);
             getchar();
             scanf("option = %d",&option);
             switch (option)
             {
             case 1:
                 char editname[40];
                 printf("Enter name to edit :\n");
                 scanf(" %[^\n]",editname);
                  int flag=validate_name(editname);
                  if(flag==0)
                  {
                     strcpy(addressBook->contacts[j].name,editname); // copy new name to old name
                     printf("Name edited successfully!");
                     return;
                  }
                  else
                  {
                    printf("Enter the valid name\n");  // display this message if user enter invalid name
                    return;
                  }
                  break;
             case 2:
                 char editphone[13];
                 printf("Enter the new phone\n");
                 scanf(" %[^\n]",editphone);  // read new phone number

                 flag=validate_number(editphone,addressBook);
                 if(flag==0)
                 {
                    strcpy(addressBook->contacts[j].phone,editphone);  // copy new phone number to old
                    printf("phone number edited successfully");
                    return;
                 }
                 else
                 {
                    printf("Enter valid phone number\n");
                    return;
                 }
                   break;
             case 3:
                 char editmail[30];
                 printf("Enter the new mail id :\n");
                 scanf(" %[^\n]",editmail);
                 flag = validate_email(editmail,addressBook);
                 if(flag==0)
                 {
                    strcpy(addressBook->contacts[j].email,editmail);   // copy new mail to old
                    printf("Email id edited successfully!");
                    return;
                 }  
                 else
                 {
                    printf("Enter valid mail id\n");
                    return;
                 }     
                 break;
             
             default:
                  printf("Invalid option\n");
                break;
             }

           }
           else if(flag==0)
           {
              printf("Contact not found. \n");
              return;
           }
           else
           {
              printf("There is having multiple name of this name so search by using phone or mail id\n");
              return;
           }
         case 2:
              char searchphone[20];
              printf("Enter phone number to edit: ");
              scanf(" %[^\n]",searchphone);
              int i,flag1=0;
              for(i=0;i<addressBook->contactCount;i++)
              {
                if(strcasecmp(addressBook->contacts[i].phone,searchphone)==0)
                {
                    flag1=1;  // if found make flag 1
                    break;
                }
              }
             if(flag1==0)
             {
                printf("Invalid phone number\n");
             } 
             else
             {
                printf("Contact found: Name %s, phone: %s, Email: %s\n",
                addressBook->contacts[i].name,
                addressBook->contacts[i].phone,
                addressBook->contacts[i].email);
             int option1;
             printf("What you want to edit :\n");
             printf("Enter 1 to edit name\n");
             printf("Enter 2 to edit phone\n");
             printf("Enter 3 to edit email\n");
             scanf("%d",&option1);

            switch (option1)
             {
             case 1:
                 char editname[40];
                 printf("Enter name to edit :\n");
                 scanf(" %[^\n]",editname);
                  int flag=validate_name(editname);
                  if(flag==0)
                  {
                     strcpy(addressBook->contacts[i].name,editname); // copy new name to old name
                     printf("Name edited successfully!");
                     return;
                  }
                  else
                  {
                    printf("Enter the valid name\n");  // display this message if user enter invalid name
                    return;
                  }
                  break;
             case 2:
                 char editphone[13];
                 printf("Enter the new phone\n");
                 scanf(" %[^\n]",editphone);  // read new phone number

                 flag=validate_number(editphone,addressBook);
                 if(flag==0)
                 {
                    strcpy(addressBook->contacts[j].phone,editphone);  // copy new phone number to old
                    printf("phone number edited successfully");
                    return;
                 }
                 else
                 {
                    printf("Enter valid phone number\n");
                    return;
                 }
                   break;
             case 3:
                 char editmail[30];
                 printf("Enter the new mail id :\n");
                 scanf(" %[^\n]",editmail);
                 flag = validate_email(editmail,addressBook);
                 if(flag==0)
                 {
                    strcpy(addressBook->contacts[j].email,editmail);   // copy new mail to old
                    printf("Email id edited successfully!");
                    return;
                 }  
                 else
                 {
                    printf("Enter valid mail id\n");
                    return;
                 }     
                 break;
             
             default:
                  printf("Invalid option\n");
                break;
             }

           }
         case 3:
            char searchemail[20];
            printf("Enter email to search :\n");
            scanf(" %[^\n]",searchemail);  // read email to search
            for(i=0;i<addressBook->contactCount;i++)
            {
                if(strcasecmp(addressBook->contacts[i].email,searchemail)==0)
                {
                     printf("Contact found: Name %s, phone: %s, Email: %s\n",
                     addressBook->contacts[i].name,
                     addressBook->contacts[i].phone,
                     addressBook->contacts[i].email);
                        int option2;
                     printf("What you want to edit :\n");
                     printf("Enter 1 to edit name\n");
                     printf("Enter 2 to edit phone\n");
                     printf("Enter 3 to edit email\n");
                     scanf("option = %d",&option2);

            switch (option2)
             {
             case 1:
                 char editname[40];
                 printf("Enter name to edit :\n");
                 scanf(" %[^\n]",editname);
                  int flag=validate_name(editname);
                  if(flag==0)
                  {
                     strcpy(addressBook->contacts[j].name,editname); // copy new name to old name
                     printf("Name edited successfully!");
                     return;
                  }
                  else
                  {
                    printf("Enter the valid name\n");  // display this message if user enter invalid name
                    return;
                  }
                  break;
             case 2:
                 char editphone[13];
                 printf("Enter the new phone\n");
                 scanf(" %[^\n]",editphone);  // read new phone number

                 flag=validate_number(editphone,addressBook);
                 if(flag==0)
                 {
                    strcpy(addressBook->contacts[j].phone,editphone);  // copy new phone number to old
                    printf("phone number edited successfully");
                    return;
                 }
                 else
                 {
                    printf("Enter valid phone number\n");
                    return;
                 }
                   break;
             case 3:
                 char editmail[30];
                 printf("Enter the new mail id :\n");
                 scanf(" %[^\n]",editmail);
                 flag = validate_email(editmail,addressBook);
                 if(flag==0)
                 {
                    strcpy(addressBook->contacts[j].email,editmail);   // copy new mail to old
                    printf("Email id edited successfully!");
                    return;
                 }  
                 else
                 {
                    printf("Enter valid mail id\n");
                    return;
                 }     
                 break;
             
             default:
                  printf("Invalid option\n");
                break;
             }

                }
            }
           default:
           printf("Enter valid choice\n");
           break; 
    }    
   
}

void deleteContact(AddressBook *addressBook)         // Functio to delete the contact
{
	/* Define the logic for deletecontact */
    if(addressBook->contactCount==0)
    {
        printf("No contact available to delete\n");
        return;
    }
    printf("Search the contact based on following option \n"); // ask user to search contact base on following option to delete that contact
    printf("Enter 1 to search by name\n");
    printf("Enter 2 to search by phone\n");
    printf("Enter 3 to search by email\n");
    int choice1;
    scanf("%d",&choice1); // read the choice
    switch (choice1)
    {
    case 1:
        char deletename[40];
        printf("Enter the name which you want to delete\n");
        scanf(" %[^\n]",deletename);
        int flag3=0;
        int j=0;
        for(int i=0;i<addressBook->contactCount;i++)
        {
            if(strcasecmp(addressBook->contacts[i].name,deletename)==0)
            {
                flag3++;  // increament the flag value if contact is found
                j=i;     // store the index of contact in other variable for future use
            }
        }
        if(flag3==1)
        {
            for(int i=j;i<addressBook->contactCount-1;i++)
            {
                addressBook->contacts[i]=addressBook->contacts[i+1]; //shift the contact
            }
            addressBook->contactCount--; // decreament the contactcount
            return;
        }
        else if(flag3==0)
        {
            printf("Contact not found\n");
            return;
        }
        else{
            // if more than one contact with same name then search base on phone or mail
            printf("There is having more than one contact with same name\n");

            printf("Enter 1 to delete contact base on phone number\n");
            printf("Enter 2 to delete contact base on email id\n");

            int option4;
            printf("Enter option :\n");
            scanf("%d",&option4);
            switch (option4)
            {
            case 1:
                char phone[13];
                printf("Enter phone number: ");
                scanf(" %[^\n]",phone);
                for(int i=0;i<addressBook->contactCount-1;i++)
                {
                    if(strcasecmp(addressBook->contacts[i].phone,phone)==0) // if number is found then delete the contact
                    {
                        for(int j=i;j<addressBook->contactCount-1;j++)
                        {
                            addressBook->contacts[j]=addressBook->contacts[j+1];
                        }
                        addressBook->contactCount--; // decreament the contactcount
                        printf("Contact deleted successfully\n");
                        return;
                    }
                }
                break;
             case 2:
                  char email[50];
                  printf("Enter the email id: ");
                  scanf(" %[^\n]",email);
                  for(int i=0;i<addressBook->contactCount-1;i++)
                  {
                    if(strcasecmp(addressBook->contacts[i].email,email)==0) // if mail id is found than delete the contact
                    {
                        for(int j=i;j<addressBook->contactCount-1;j++)
                        {
                            addressBook->contacts[j]=addressBook->contacts[j+1];
                        }
                        addressBook->contactCount--; // decreament the contactcount
                        return;
                    }
                  }  
                  break;

            default:
                printf("Invalid input\n");
                return;
                break;
            }
        }
        break;

        case 2:
          char phone[20];
          printf("Enter the phone number of the contact to delete: ");
          scanf(" %[^\n]",phone);
          for(int i=0;i<addressBook->contactCount-1;i++)
          {
            if(strcasecmp(addressBook->contacts[i].phone,phone)==0) // if number is found than delete the contact
            {
                for(int j=i;j<addressBook->contactCount-1;j++)
                {
                    addressBook->contacts[j]=addressBook->contacts[j+1];
                }
                addressBook->contactCount--;  // decreament the contactcount
                printf("Contact deleted successfully\n");
                return;
            }
          }
          break;

          case 3:
            char email[40];
            printf("Enter the email of contact to delete: ");
            scanf(" %[^\n]",email);
            for(int i=0;i<addressBook->contactCount-1;i++)
            {
                if(strcasecmp(addressBook->contacts[i].email,email)==0)  // if email is found than delete the contact
                {
                    for(int j=i;j<addressBook->contactCount;j++)
                    {
                        addressBook->contacts[j]=addressBook->contacts[j+1];
                    }
                    addressBook->contactCount--; // decreament the contactcount
                    printf("Contact deleted successfully!\n");
                    return;
                }
            }
            break;
    
    default:
        printf("Invalid input\n");
        return;
        break;
    }   
}
